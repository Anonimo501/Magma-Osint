# Magma-OSINT

Herramienta de investigación web para recopilar resultados públicos de varios motores, probar consultas relacionadas, deduplicar enlaces, mostrar fragmentos y guardar un informe Markdown. Mantiene las entradas anteriores y ahora permite controlar profundidad, motores y alcance.

## Inicio rápido

**Linux/macOS:** ejecuta `./run.sh`. El lanzador prepara `.venv`, muestra la instalación/verificación de dependencias y luego pregunta la consulta. En Debian/Kali, si no existe el módulo venv: `sudo apt install python3-venv`.

**Windows:** ejecuta `run.bat`. Requiere Python 3.10+ en PATH. La primera instalación necesita Internet; los paquetes se instalan en el entorno local `.venv`, no globalmente.

Para una búsqueda amplia de un tema:

```bash
./run.sh --scope topic --engine all --depth 3 --limit 10 "energía solar"
```

Para una búsqueda limitada a información pública profesional/oficial sobre una persona pública o una búsqueda autorizada:

```bash
./run.sh --scope public-person --engine all --depth 3 --limit 10 "Ada Lovelace"
```

En Windows usa `run.bat` en lugar de `./run.sh`. Los informes se guardan en `results/` como archivos Markdown.

## Profundidad y alcance

`--depth 1` ejecuta la consulta base; `--depth 2` añade variantes relacionadas; `--depth 3` amplía con consultas de investigación, reportes, novedades o publicaciones profesionales según el alcance. El modo `topic` sirve para temas, productos, organizaciones y entidades. `public-person` se restringe a resultados profesionales/oficiales y omite redes sociales personales, páginas de búsqueda de personas y resultados legales; no busca correos, teléfonos ni domicilios. Los motores pueden devolver homónimos: verifica las fuentes antes de atribuir información.

El buscador prueba Google, DuckDuckGo y Bing (`--engine all`, valor por defecto), muestra títulos y fragmentos cuando el proveedor los ofrece, elimina URLs duplicadas e inspecciona hasta 20 páginas públicas por ejecución. `--pages 0` desactiva esa inspección de páginas; `--pages N` cambia el tope. Los motores o sitios pueden limitar, bloquear o no indexar contenido, por lo que ninguna herramienta puede garantizar exhaustividad.

```bash
python osint.py --help
python osint.py --scope topic --depth 2 --engine web --limit 10 "Python programación"
python osint.py --scope public-person --depth 2 --output informe.md "Ada Lovelace"
```

La variante histórica `MagmaOsint 2025/osint_ddg_bing.py` sigue disponible y ejecuta DDG+Bing.

## Instalación manual

```bash
python3 -m venv .venv
# Linux/macOS: source .venv/bin/activate
# Windows PowerShell: .venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python osint.py --help
```

## Pruebas

```bash
python -m unittest discover -s tests -v
```

Las pruebas unitarias no necesitan acceso a los buscadores. Las consultas reales dependen de la conectividad, idioma y disponibilidad de cada proveedor.

## Uso responsable

Usa el programa en información pública y de forma legal; respeta términos de uso, límites de solicitudes, privacidad y derechos de las personas. El modo de personas se limita deliberadamente a información profesional/oficial y no elude controles de acceso.
