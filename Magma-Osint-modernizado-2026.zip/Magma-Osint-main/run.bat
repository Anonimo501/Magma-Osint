@echo off
setlocal
cd /d "%~dp0"
set "VENV=%~dp0.venv"
if not exist "%VENV%\Scripts\python.exe" (
    echo [Magma-OSINT] Creando entorno virtual en .venv...
    where py >nul 2>nul
    if %errorlevel%==0 (
        py -3 -m venv "%VENV%"
    ) else (
        python -m venv "%VENV%"
    )
    if errorlevel 1 goto :venv_error
)
echo [Magma-OSINT] Instalando/verificando dependencias de requirements.txt; no se modifica Python global...
"%VENV%\Scripts\python.exe" -m pip install --disable-pip-version-check -r "%~dp0requirements.txt"
if errorlevel 1 goto :pip_error
"%VENV%\Scripts\python.exe" "%~dp0osint.py" %*
exit /b %errorlevel%
:venv_error
echo [ERROR] No se pudo crear el entorno virtual. Instala Python 3.10+ y vuelve a intentarlo.
exit /b 1
:pip_error
echo [ERROR] No se pudieron instalar las dependencias. Comprueba Internet y pip.
exit /b 1
