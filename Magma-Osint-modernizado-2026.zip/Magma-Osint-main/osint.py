#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Entrada tradicional de Magma-OSINT; usa todos los motores por defecto."""

from magma_osint import main


if __name__ == "__main__":
    raise SystemExit(main(default_engine="all"))
