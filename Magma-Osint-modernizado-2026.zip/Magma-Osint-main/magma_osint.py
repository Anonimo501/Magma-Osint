#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Magma-OSINT: investigación web pública con resultados trazables."""

from __future__ import annotations

import argparse
import base64
import re
import sys
import time
from collections.abc import Callable, Iterable, Iterator
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs, parse_qsl, unquote, urlencode, urldefrag, urljoin, urlparse, urlunparse

import requests
from bs4 import BeautifulSoup
from colorama import Back, Fore, init
from rapidfuzz import fuzz

init(autoreset=True)

LOGO = r"""
  █▀▄▀█ █▀▀█ █▀▀▀ █▀▄▀█ █▀▀█   █▀▀█ █▀▀ ░▀░ █▀▀▄ ▀▀█▀▀
  █░▀░█ █▄▄█ █░▀█ █░▀░█ █▄▄█   █░░█ ▀▀█ ▀█▀ █░░█ ░░█░░
  ▀░░░▀ ▀░░▀ ▀▀▀▀ ▀░░░▀ ▀░░▀   ▀▀▀▀ ▀▀▀ ▀▀▀ ▀░░▀ ░░▀░░
                                   Created by LimerBoy
"""
USER_AGENT = (
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/131.0 Safari/537.36"
)
HEADERS = {"User-Agent": USER_AGENT, "Accept-Language": "es,en;q=0.8"}


@dataclass(frozen=True)
class SearchHit:
    url: str
    title: str = ""
    snippet: str = ""
    provider: str = ""
    query: str = ""


@dataclass
class HitRecord:
    hit: SearchHit
    providers: set[str] = field(default_factory=set)
    queries: set[str] = field(default_factory=set)
    page_title: str = ""


def normalize_url(href: str | None, base: str | None = None) -> str | None:
    """Resolve links and allow only absolute HTTP(S) URLs."""
    if not href:
        return None
    href = href.strip()
    if not href or href.startswith(("javascript:", "mailto:", "tel:", "#", "data:")):
        return None
    if href.startswith("//"):
        href = "https:" + href
    elif base:
        href = urljoin(base, href)
    parsed = urlparse(href)
    # Bing sometimes wraps organic/ad destinations in base64 tracking URLs.
    if (parsed.hostname or "").casefold().endswith("bing.com") and parsed.path.startswith(("/aclick", "/ck/a")):
        encoded = parse_qs(parsed.query).get("u", [""])[0]
        if encoded:
            try:
                if encoded.startswith("a1"):
                    encoded = encoded[2:]
                decoded = unquote(base64.urlsafe_b64decode(encoded + "=" * (-len(encoded) % 4)).decode("utf-8"))
                if decoded.startswith(("http://", "https://")):
                    href = decoded
                    parsed = urlparse(href)
            except (ValueError, UnicodeDecodeError):
                pass
    if parsed.scheme.lower() not in {"http", "https"} or not parsed.netloc:
        return None
    tracking_keys = {"gclid", "fbclid", "msclkid", "ref", "ref_src", "source"}
    query_items = parse_qsl(parsed.query, keep_blank_values=True)
    clean_query = urlencode([
        (key, value) for key, value in query_items
        if key.casefold() not in tracking_keys and not key.casefold().startswith("utm_")
    ])
    href = urlunparse(parsed._replace(query=clean_query))
    return urldefrag(href).url


def sanitize_public_text(text: str, max_length: int = 500) -> str:
    """Remove direct contact strings from snippets in public-person mode."""
    text = re.sub(r"\b[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}\b", "[correo omitido]", text)
    text = re.sub(r"(?<!\w)(?:\+?\d[\d ().-]{7,}\d)(?!\w)", "[teléfono omitido]", text)
    return " ".join(text.split())[:max_length]


def expand_queries(query: str, scope: str = "topic", depth: int = 2) -> list[str]:
    """Create bounded, purpose-specific query variants (depth 1–3)."""
    query = query.strip()
    exact = f'"{query}"'
    if scope == "public-person":
        variants = [exact]
        if depth >= 2:
            variants += [f'{exact} official biography', f'{exact} professional profile']
        if depth >= 3:
            variants += [
                f'{exact} publications research author',
                f'{exact} university company organization team',
                f'{exact} official site professional work',
            ]
    else:
        variants = [query]
        if depth >= 2:
            variants += [exact, f'{query} overview guide', f'{query} official documentation']
        if depth >= 3:
            variants += [
                f'{query} research report',
                f'{query} news developments',
                f'{query} analysis comparison',
                f'{query} examples use cases',
            ]
    return list(dict.fromkeys(variants))


def google_results(query: str, max_results: int) -> Iterator[SearchHit]:
    """Yield Google links from the maintained googlesearch-python API."""
    from googlesearch import search

    for result in search(query, num_results=max_results, sleep_interval=1.0):
        url = normalize_url(str(result))
        if url:
            yield SearchHit(url=url, provider="Google", query=query)


def ddgs_results(query: str, max_results: int, backend: str) -> Iterator[SearchHit]:
    """Yield DDGS result titles, summaries and links, with automatic fallback."""
    from ddgs import DDGS

    provider_label = backend
    try:
        results = DDGS().text(query, max_results=max_results, backend=backend)
    except Exception as exc:
        if backend == "auto":
            raise
        print(Fore.YELLOW + f"[!] {backend} directo no respondió ({exc}); probando el respaldo automático.")
        results = DDGS().text(query, max_results=max_results, backend="auto")
        provider_label = "DDGS (respaldo automático)"
    if not results and backend != "auto":
        print(Fore.YELLOW + f"[!] {backend} no devolvió resultados; probando el respaldo automático.")
        results = DDGS().text(query, max_results=max_results, backend="auto")
        provider_label = "DDGS (respaldo automático)"

    for result in results:
        if isinstance(result, dict):
            url = normalize_url(result.get("href") or result.get("url"))
            title = str(result.get("title") or "")
            snippet = str(result.get("body") or result.get("snippet") or result.get("description") or "")
        else:
            url = normalize_url(str(result))
            title, snippet = "", ""
        if url:
            yield SearchHit(url=url, title=title, snippet=snippet, provider=provider_label, query=query)


def result_sources(engine: str, query: str, max_results: int) -> list[tuple[str, Callable[[], Iterable[SearchHit]]]]:
    """Return enabled search providers in the requested order."""
    sources: list[tuple[str, Callable[[], Iterable[SearchHit]]]] = []
    if engine in {"google", "all"}:
        sources.append(("Google", lambda: google_results(query, max_results)))
    if engine in {"web", "all"}:
        sources.append(("DuckDuckGo", lambda: ddgs_results(query, max_results, "duckduckgo")))
        sources.append(("Bing", lambda: ddgs_results(query, max_results, "bing")))
    return sources


def _coerce_hit(raw: SearchHit | str, provider: str, query: str) -> SearchHit | None:
    if isinstance(raw, SearchHit):
        url = normalize_url(raw.url)
        if not url:
            return None
        return SearchHit(url, raw.title, raw.snippet, raw.provider or provider, raw.query or query)
    url = normalize_url(str(raw))
    return SearchHit(url=url, provider=provider, query=query) if url else None


def is_public_professional_hit(hit: SearchHit) -> bool:
    """Keep person-mode results focused on public professional sources."""
    url_lower = hit.url.casefold()
    text = f"{hit.title} {hit.snippet} {url_lower}".casefold()
    excluded = (
        "facebook.com", "instagram.com", "tiktok.com", "jusbrasil", "escavador",
        "processo judicial", "court case", "arrest", "criminal record", "phone lookup",
        "people search", "address lookup",
    )
    if any(term in text for term in excluded):
        return False
    professional = (
        "linkedin.com", "orcid.org", "scholar.google", "researchgate.net", "github.com",
        "official", "professional", "biography", "publications", "researcher", "research",
        "professor", "author", "faculty", "university", "company", "organization", "team",
        "staff", "director", "founder", "portfolio", "curriculum", "currículo", "profesional",
        "biografía", "publicaciones", "investigador", "profesor", "universidad", "empresa",
        "instituto", "institución", "autor",
    )
    return any(term in text for term in professional)


def analyze_page(url: str, query: str, timeout: float = 8.0, session: Any = requests,
                 public_person: bool = False) -> tuple[str, list[str]]:
    """Fetch a public result page title and identify relevant hyperlinks."""
    print("\n" + Fore.CYAN + f"[+] Página: {url}")
    try:
        response = session.get(url, headers=HEADERS, timeout=timeout)
        response.raise_for_status()
    except requests.RequestException as exc:
        print(Fore.RED + f"   (página inaccesible: {exc})")
        return "", []

    soup = BeautifulSoup(response.text, "html.parser")
    title = soup.title.get_text(" ", strip=True) if soup.title else ""
    if public_person:
        title = sanitize_public_text(title, 240)
    if title:
        print(Fore.MAGENTA + f"[?] Título: {title}")

    found: list[str] = []
    seen: set[str] = set()
    source_host = (urlparse(url).hostname or "").casefold()
    query_folded = query.casefold()
    for link in soup.find_all("a", href=True):
        href = normalize_url(link.get("href"), base=url)
        if not href or href in seen:
            continue
        seen.add(href)
        link_host = (urlparse(href).hostname or "").casefold()
        anchor_text = link.get_text(" ", strip=True)
        if (source_host and link_host == source_host) or query_folded in href.casefold():
            found.append(href)
        elif anchor_text and fuzz.ratio(anchor_text, href) >= 60:
            found.append(href)
    return title, found


def _print_hit(hit: SearchHit, scope: str) -> None:
    title = hit.title.strip() or "(título no proporcionado por el buscador)"
    snippet = hit.snippet.strip()
    if scope == "public-person":
        title = sanitize_public_text(title, 240)
        snippet = sanitize_public_text(snippet, 500)
    print(Fore.CYAN + f"[+] {title}")
    print(Fore.WHITE + f"    URL: {hit.url}")
    if snippet:
        print(Fore.WHITE + f"    Fragmento: {snippet}")


def write_report(path: str | Path, query: str, scope: str, depth: int, records: dict[str, HitRecord], related_links: set[str]) -> Path:
    """Save deduplicated citations and search context as a Markdown report."""
    output = Path(path).expanduser()
    output.parent.mkdir(parents=True, exist_ok=True)
    safe_query = sanitize_public_text(query, 300) if scope == "public-person" else query
    lines = [
        "# Informe de búsqueda web",
        "",
        f"- Consulta: {safe_query}",
        f"- Alcance: {'información pública profesional/oficial' if scope == 'public-person' else 'tema u organización'}",
        f"- Profundidad: {depth}",
        f"- Fecha de generación: {datetime.now().astimezone().isoformat(timespec='minutes')}",
        f"- Resultados únicos: {len(records)}",
        "",
        "> Los resultados son pistas de búsqueda, no confirmación de identidad ni garantía de exhaustividad. Algunos sitios limitan o bloquean el acceso.",
        "",
        "## Resultados",
        "",
    ]
    if not records:
        lines.append("No se obtuvieron resultados en esta ejecución.")
    for index, record in enumerate(records.values(), 1):
        hit = record.hit
        title = hit.title.strip() or record.page_title or "Resultado sin título"
        snippet = hit.snippet.strip()
        if scope == "public-person":
            title = sanitize_public_text(title, 240)
            snippet = sanitize_public_text(snippet, 500)
        lines += [
            f"### {index}. {title}",
            f"- URL: {hit.url}",
            f"- Buscador(es): {', '.join(sorted(record.providers)) or hit.provider}",
            f"- Consulta(s): {'; '.join(sorted(record.queries)) or hit.query}",
        ]
        if snippet:
            lines.append(f"- Fragmento: {snippet}")
        lines.append("")
    if related_links:
        lines += ["## Enlaces relacionados detectados en páginas accesibles", ""]
        lines.extend(f"- {url}" for url in sorted(related_links))
    output.write_text("\n".join(lines).rstrip() + "\n", encoding="utf-8")
    return output


def run_search(
    query: str,
    engine: str = "all",
    max_results: int = 10,
    timeout: float = 8.0,
    delay: float = 0.3,
    scope: str = "topic",
    depth: int = 2,
    max_pages: int = 20,
    output_path: str | Path | None = None,
) -> dict[str, HitRecord]:
    """Search several query variants and providers, then optionally write a report."""
    print(Fore.YELLOW + LOGO)
    print(Fore.GREEN + f"[~] Consulta: {query}")
    if scope == "public-person":
        print(Fore.YELLOW + "[i] Alcance limitado a información pública profesional/oficial; no se buscan contactos ni datos privados.")
    queries = expand_queries(query, scope=scope, depth=depth)
    print(Fore.YELLOW + f"[i] Profundidad {depth}: {len(queries)} variantes; motores: {engine}; hasta {max_results} resultados por motor/variante.")

    records: dict[str, HitRecord] = {}
    related_links: set[str] = set()
    inspected_pages = 0
    total_provider_hits = 0
    for search_query in queries:
        print(Fore.YELLOW + f"\n[~] Consulta derivada: {search_query}")
        sources = result_sources(engine, search_query, max_results)
        source_index = 0
        google_count = 0
        while source_index < len(sources):
            source_name, source_factory = sources[source_index]
            source_index += 1
            print(Fore.YELLOW + f"[~] Buscador: {source_name}")
            count = 0
            try:
                for raw_hit in source_factory():
                    hit = _coerce_hit(raw_hit, source_name, search_query)
                    if not hit:
                        continue
                    if scope == "public-person" and not is_public_professional_hit(hit):
                        continue
                    count += 1
                    total_provider_hits += 1
                    if source_name == "Google":
                        google_count += 1
                    record = records.get(hit.url)
                    if record:
                        record.providers.add(hit.provider or source_name)
                        record.queries.add(search_query)
                    else:
                        record = HitRecord(hit=hit, providers={hit.provider or source_name}, queries={search_query})
                        records[hit.url] = record
                        _print_hit(hit, scope)
                        if inspected_pages < max_pages:
                            page_title, page_links = analyze_page(
                                hit.url, search_query, timeout=timeout,
                                public_person=(scope == "public-person"),
                            )
                            record.page_title = page_title
                            if scope == "topic":
                                related_links.update(page_links)
                            inspected_pages += 1
                        elif inspected_pages == max_pages:
                            print(Fore.YELLOW + f"[i] Tope de inspección de páginas alcanzado ({max_pages}); continúo recopilando títulos y fragmentos del buscador.")
                            inspected_pages += 1
                    if count >= max_results:
                        break
                    if delay:
                        time.sleep(delay)
                if count == 0:
                    print(Fore.YELLOW + f"[!] {source_name}: sin resultados para esta variante.")
            except KeyboardInterrupt:
                raise
            except Exception as exc:
                print(Fore.RED + f"[!] {source_name} no pudo completar esta variante: {exc}")

            # A lone Google engine still falls back to web sources if blocked.
            if engine == "google" and source_name == "Google" and google_count == 0:
                print(Fore.YELLOW + "[!] Google no devolvió resultados; pruebo DuckDuckGo y Bing para esta variante.")
                sources.extend(result_sources("web", search_query, max_results))

    if not records:
        print(Fore.RED + "[!] No se obtuvieron resultados permitidos. Puede ser una consulta sin coincidencias, filtros del alcance elegido o restricciones de red/proveedor.")
    else:
        print(Fore.GREEN + f"\n[+] Resultados únicos: {len(records)} (hallazgos de proveedores antes de deduplicar: {total_provider_hits}).")
    if output_path:
        report = write_report(output_path, query, scope, depth, records, related_links)
        print(Fore.GREEN + f"[+] Informe guardado: {report.resolve()}")
    print(Fore.GREEN + "[+] Search finished.")
    return records


def main(default_engine: str = "all", argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Investigación web ampliada de temas y organizaciones o información profesional pública de personas."
    )
    parser.add_argument("query", nargs="?", help="tema, organización o nombre de persona pública")
    parser.add_argument("--engine", choices=("google", "web", "all"), default=default_engine,
                        help="motores Google, DuckDuckGo+Bing o todos (predeterminado: %(default)s)")
    parser.add_argument("--scope", choices=("topic", "public-person"), default="topic",
                        help="topic para temas/organizaciones; public-person limita resultados a información profesional/oficial")
    parser.add_argument("--depth", type=int, choices=(1, 2, 3), default=2,
                        help="cantidad de variantes de consulta: 1 básica, 2 ampliada, 3 más exhaustiva (predeterminado: 2)")
    parser.add_argument("--limit", type=int, default=10,
                        help="máximo de resultados por motor y variante (predeterminado: 10)")
    parser.add_argument("--pages", type=int, default=20,
                        help="máximo de páginas de resultados que se inspeccionan por ejecución (predeterminado: 20)")
    parser.add_argument("--timeout", type=float, default=8.0, help="tiempo máximo por página, en segundos")
    parser.add_argument("--delay", type=float, default=0.3, help="pausa entre resultados, en segundos")
    parser.add_argument("--output", default=None, help="ruta del informe Markdown (por defecto results/magma-osint-FECHA.md)")
    args = parser.parse_args(argv)
    if args.limit < 1 or args.pages < 0:
        parser.error("--limit debe ser positivo y --pages no puede ser negativo")
    if args.timeout <= 0 or args.delay < 0:
        parser.error("--timeout debe ser positivo y --delay no puede ser negativo")

    query = (args.query or input(Back.BLACK + Fore.YELLOW + "Find > " + Back.RESET + Fore.WHITE)).strip()
    if not query:
        parser.error("la consulta no puede estar vacía")
    output = args.output or Path("results") / f"magma-osint-{datetime.now().strftime('%Y%m%d-%H%M%S')}.md"
    try:
        run_search(query, engine=args.engine, max_results=args.limit, timeout=args.timeout,
                   delay=args.delay, scope=args.scope, depth=args.depth, max_pages=args.pages,
                   output_path=output)
    except KeyboardInterrupt:
        print(Fore.RED + "\n[!] Búsqueda interrumpida por el usuario (Ctrl+C).")
        return 130
    return 0


if __name__ == "__main__":
    sys.exit(main())
