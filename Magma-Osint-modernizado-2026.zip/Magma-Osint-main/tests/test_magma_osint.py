import unittest
import base64
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import Mock, patch
from urllib.parse import quote

import requests

import magma_osint


class NormalizeUrlTests(unittest.TestCase):
    def test_absolute_http_and_fragment_removed(self):
        self.assertEqual(
            magma_osint.normalize_url("https://example.org/a#top"),
            "https://example.org/a",
        )

    def test_relative_link_is_resolved(self):
        self.assertEqual(
            magma_osint.normalize_url("/profile", "https://example.org/search"),
            "https://example.org/profile",
        )

    def test_non_web_schemes_are_rejected(self):
        for value in ("javascript:alert(1)", "mailto:a@b.test", "data:text/plain,x", "#part"):
            with self.subTest(value=value):
                self.assertIsNone(magma_osint.normalize_url(value, "https://example.org"))

    def test_protocol_relative_url(self):
        self.assertEqual(magma_osint.normalize_url("//example.org/a"), "https://example.org/a")

    def test_bing_tracking_redirect_is_unwrapped(self):
        target = "https://docs.example.org/guide"
        encoded = base64.urlsafe_b64encode(quote(target, safe="").encode()).decode().rstrip("=")
        self.assertEqual(
            magma_osint.normalize_url(f"https://www.bing.com/aclick?u={encoded}"),
            target,
        )

    def test_marketing_parameters_are_removed_from_urls(self):
        self.assertEqual(
            magma_osint.normalize_url("https://example.org/page?utm_source=bing&id=7&msclkid=abc#top"),
            "https://example.org/page?id=7",
        )

    def test_query_expansion_scales_with_depth_and_scope(self):
        topic_basic = magma_osint.expand_queries("solar power", "topic", 1)
        topic_deep = magma_osint.expand_queries("solar power", "topic", 3)
        person_deep = magma_osint.expand_queries("Ada Lovelace", "public-person", 3)

        self.assertEqual(topic_basic, ["solar power"])
        self.assertGreater(len(topic_deep), len(topic_basic))
        self.assertTrue(all("Ada Lovelace" in query for query in person_deep))
        self.assertTrue(any("publications" in query for query in person_deep))

    def test_public_person_results_are_restricted_to_professional_sources(self):
        professional = magma_osint.SearchHit(
            "https://www.linkedin.com/in/example", title="Professional profile"
        )
        personal_social = magma_osint.SearchHit(
            "https://www.instagram.com/example", title="Instagram profile"
        )
        legal_record = magma_osint.SearchHit(
            "https://example.org/cases", title="Publications about court case"
        )

        self.assertTrue(magma_osint.is_public_professional_hit(professional))
        self.assertFalse(magma_osint.is_public_professional_hit(personal_social))
        self.assertFalse(magma_osint.is_public_professional_hit(legal_record))

    def test_public_person_text_omits_email_and_phone(self):
        text = "Author contact jane@example.org or +1 (555) 123-4567"
        safe = magma_osint.sanitize_public_text(text)
        self.assertNotIn("jane@example.org", safe)
        self.assertNotIn("555", safe)


class SearchSourceTests(unittest.TestCase):
    def test_default_engines_keep_original_provider_sets(self):
        self.assertEqual([name for name, _ in magma_osint.result_sources("google", "x", 10)], ["Google"])
        self.assertEqual(
            [name for name, _ in magma_osint.result_sources("web", "x", 10)],
            ["DuckDuckGo", "Bing"],
        )
        self.assertEqual(
            [name for name, _ in magma_osint.result_sources("all", "x", 10)],
            ["Google", "DuckDuckGo", "Bing"],
        )

    def test_duckduckgo_uses_automatic_fallback_when_direct_source_fails(self):
        with patch("ddgs.DDGS") as ddgs_class:
            ddgs_class.return_value.text.side_effect = [
                RuntimeError("provider unavailable"),
                [{"href": "https://example.test/result"}],
            ]
            results = list(magma_osint.ddgs_results("query", 5, "duckduckgo"))

        self.assertEqual([hit.url for hit in results], ["https://example.test/result"])
        self.assertEqual(ddgs_class.return_value.text.call_args_list[1].kwargs["backend"], "auto")

    def test_bing_uses_automatic_fallback_when_direct_source_fails(self):
        with patch("ddgs.DDGS") as ddgs_class:
            ddgs_class.return_value.text.side_effect = [
                RuntimeError("provider unavailable"),
                [{"href": "https://example.test/result"}],
            ]
            results = list(magma_osint.ddgs_results("query", 5, "bing"))

        self.assertEqual([hit.url for hit in results], ["https://example.test/result"])
        self.assertEqual(ddgs_class.return_value.text.call_args_list[1].kwargs["backend"], "auto")

    def test_google_zero_results_automatically_runs_alternative_providers(self):
        def fake_ddgs(query, limit, backend):
            return iter([f"https://{backend}.example.test/result"])

        with patch("magma_osint.google_results", return_value=iter(())), \
             patch("magma_osint.ddgs_results", side_effect=fake_ddgs) as providers, \
             patch("magma_osint.analyze_page", return_value=("", [])) as analyze, \
             patch("builtins.print"):
            magma_osint.run_search("sample query", engine="google", max_results=1, delay=0, depth=1)

        self.assertEqual([call.args[2] for call in providers.call_args_list], ["duckduckgo", "bing"])
        self.assertEqual(analyze.call_count, 2)

    def test_ddgs_result_keeps_title_and_snippet(self):
        with patch("ddgs.DDGS") as ddgs_class:
            ddgs_class.return_value.text.return_value = [{
                "href": "https://example.test/page",
                "title": "Page title",
                "body": "Useful search summary",
            }]
            results = list(magma_osint.ddgs_results("query", 5, "bing"))

        self.assertEqual(results[0].title, "Page title")
        self.assertEqual(results[0].snippet, "Useful search summary")

    def test_report_contains_deduplicated_result_context(self):
        hit = magma_osint.SearchHit(
            "https://example.test/page", "Example title", "A short summary", "Bing", "example query"
        )
        records = {
            hit.url: magma_osint.HitRecord(
                hit, providers={"Bing", "DuckDuckGo"}, queries={"example query"}
            )
        }
        with TemporaryDirectory() as tmp:
            output = magma_osint.write_report(
                Path(tmp) / "report.md", "example query", "topic", 2, records, set()
            )
            content = output.read_text(encoding="utf-8")

        self.assertIn("Example title", content)
        self.assertIn("A short summary", content)
        self.assertIn("Bing, DuckDuckGo", content)


class AnalyzePageTests(unittest.TestCase):
    def test_title_and_relevant_links_are_extracted(self):
        response = Mock()
        response.text = """
            <html><title>Example title</title><body>
              <a href='/same'>Internal</a>
              <a href='https://other.test/Ada-Lovelace'>Ada profile</a>
              <a href='javascript:alert(1)'>bad</a>
            </body></html>
        """
        response.raise_for_status.return_value = None
        session = Mock()
        session.get.return_value = response

        title, found = magma_osint.analyze_page("https://example.test/start", "Ada-Lovelace", session=session)

        self.assertEqual(title, "Example title")
        self.assertIn("https://example.test/same", found)
        self.assertIn("https://other.test/Ada-Lovelace", found)
        self.assertFalse(any(url.startswith("javascript:") for url in found))

    def test_request_error_is_handled(self):
        session = Mock()
        session.get.side_effect = requests.Timeout("timed out")
        self.assertEqual(magma_osint.analyze_page("https://example.test", "x", session=session), ("", []))


if __name__ == "__main__":
    unittest.main()
