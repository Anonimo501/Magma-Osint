#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Entrada compatible de búsqueda DuckDuckGo + Bing."""

from pathlib import Path
import sys

# Permite ejecutar este archivo directamente desde su subcarpeta histórica.
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from magma_osint import main  # noqa: E402


if __name__ == "__main__":
    raise SystemExit(main(default_engine="web"))
