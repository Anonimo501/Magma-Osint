#!/usr/bin/env sh
set -eu
PROJECT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd "$PROJECT_DIR"
PYTHON=${PYTHON:-python3}
VENV="$PROJECT_DIR/.venv"

if [ ! -x "$VENV/bin/python" ]; then
    echo "[Magma-OSINT] Creando entorno virtual en .venv..."
    if ! "$PYTHON" -m venv "$VENV"; then
        echo "[ERROR] No se pudo crear el entorno virtual. Instala Python 3.10+ y el módulo venv (en Debian/Kali: sudo apt install python3-venv)." >&2
        exit 1
    fi
fi

echo "[Magma-OSINT] Instalando/verificando dependencias de requirements.txt (no se modifica Python global)..."
if ! "$VENV/bin/python" -m pip install --disable-pip-version-check -r "$PROJECT_DIR/requirements.txt"; then
    echo "[ERROR] No se pudieron instalar las dependencias. Comprueba tu conexión a Internet y que pip esté disponible." >&2
    exit 1
fi

exec "$VENV/bin/python" "$PROJECT_DIR/osint.py" "$@"
